<?php 


$libros = Libro::all();



require '../views/libro/lista.php';
?>