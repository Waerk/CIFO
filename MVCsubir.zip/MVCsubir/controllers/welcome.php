<?php 
require '../views/portada.php';
?>