<?php
require '../views/socio/nuevo.php';