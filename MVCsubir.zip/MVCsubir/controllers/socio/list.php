<?php


$socios = Socio::all();



require '../views/socio/lista.php';
?>