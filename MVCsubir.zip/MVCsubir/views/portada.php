<?php 
require '../template/template.php';
    cabecera();
    ?>
		<h2>Bienvenido...</h2>
			<p>Esta es la portada del primer ejemplo de gestion de libros de la biblioteca.</p>
			<p>Este ejemplo es un <b>MVC sencillo</b>, todas las peticiones pasarn por el <b>index.php</b>, que actuara de dispatcher y gestionara todos los errores.</p>			
	</body>
</html>