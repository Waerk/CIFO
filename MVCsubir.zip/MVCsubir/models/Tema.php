<?php
#[\AllowDynamicProperties]
class Tema extends Model{
    
}
