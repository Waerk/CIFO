<?php 
#[\AllowDynamicProperties]
class Libro extends Model{
    
}
