<?php
#[\AllowDynamicProperties]
class Prestamo extends Model{
    
}
