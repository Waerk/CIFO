<?php
#[\AllowDynamicProperties]
class Socio extends Model{
    
}
