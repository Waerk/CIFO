<?php

/** FormException 
 *
 * Para distinguir las excepciones que se producen en los formularios.
 *
 * Última revisión: 17/03/2024.
 * 
 * @author Robert Sallent <robertsallent@gmail.com>
 */

class FormException extends Exception{}
    
    