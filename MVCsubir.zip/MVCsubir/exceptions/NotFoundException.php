<?php

/** NotFoundException 
 *
 * Para distinguir las excepciones de recurso no encontrado.
 *
 * Última revisión: 07/04/2024.
 * 
 * @author Robert Sallent <robertsallent@gmail.com>
 */

class NotFoundException extends Exception{}
    
    