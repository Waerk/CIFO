<?php
define('AUTOLOAD_DIRECTORIES',[
    'models',
    'libraries',
    'exceptions',
]);
?>
