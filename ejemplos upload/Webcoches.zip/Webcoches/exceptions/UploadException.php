<?php

/* Clase UploadException
 *
 * Para distinguir las excepciones en la subida de ficheros
 *
 * autor: Robert Sallent
 * última revisión: 20/03/2023
 *
 */

    class UploadException extends Exception{}