<?php

/** FileException 
 *
 * Para distinguir las excepciones producidas al trabajar con ficheros.
 *
 * Última revisión: 05/04/2023
 * 
 * @author Robert Sallent <robertsallent@gmail.com>
 */

class FileException extends Exception{}
    
    