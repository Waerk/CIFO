<?php

/** EmailException 
 *
 * Para distinguir las excepciones producidas al enviar emails.
 *
 * última revisión: 05/04/2023
 * 
 * @author Robert Sallent <robertsallent@gmail.com>
 */

class EmailException extends Exception{}
    
    